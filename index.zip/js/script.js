$('button').on({
    touchstart: function(e) {
        e.preventDefault();
        clickButton(e);
    },

    mousedown: function(e) {
        e.preventDefault();
        clickButton(e);
    },

    mouseup: function(e) {
        e.preventDefault();
        releaseButton(e);
    },

    touchend: function(e){
        e.preventDefault();
        releaseButton(e);
    }
});

function clickButton(e) {
    console.log('click!');
    CrComLib.publishSignal('b','1',true);
}

function releaseButton(e) {
    console.log('release!');
    CrComLib.publishSignal('b','1',false);
}